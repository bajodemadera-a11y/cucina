CUCINA - prima versione

Apri index.html con il browser per provare l'app sul computer.
Le modifiche vengono salvate nel localStorage del browser usato.
Usa il pulsante Backup per salvare un file JSON e Importa per recuperarlo.

Per installarla come PWA sul telefono, pubblica l'intera cartella su un hosting HTTPS.
Il service worker consente la consultazione offline dopo la prima visita online.

RICETTE PRECARICATE
- Torta di Paola 3.0: ingredienti recuperati dalla ricetta riportata in chat.
- Banana bread: quantità confermate salvo mela (250-300 g, da definire); peso cotto 1530 g.
- Hamburger di ceci e soia: dosi parziali, da completare.
- Pane integrale con semi: ingredienti non recuperati; peso finale 850 g.

NUTRIZIONE
Il calcolo viene effettuato solo se tutti gli ingredienti hanno quantità in grammi e
sei valori nutrizionali completi per 100 g. Nessun valore nutrizionale è stato inventato.

Versione 1.1: funzione 'Adatta quantità' per ottenere le dosi di un peso finale cotto desiderato. I risultati sono temporanei; la ricetta originale non cambia.

Versione 1.3: Calcola cambia le dosi visualizzate nella lista Ingredienti; Ripristina originale riporta le dosi salvate. Nessun doppio elenco e nessuna sovrascrittura della ricetta.

Versione 1.4: aggiunta sezione 'Le mie note' per ogni ricetta, con salvataggio locale e backup.
